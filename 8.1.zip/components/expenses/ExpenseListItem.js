import React from 'react';
import {Text, View, StyleSheet} from 'react-native';
import {Colors, Sizes, Weights} from '../../theme/theme';

function ExpenseListItem({item}) {
  const getTextColor = (item) => {
    let toRet = {
      color: '',
    };
    const type = item.type;
    if (type === 'Income') {
      toRet.color = Colors.income;
    } else if (type === 'Expense') {
      toRet.color = Colors.expense;
    }
    return toRet;
  };

  return (
    <View style={styles.view}>
      <Text style={styles.description}>{item.desc}</Text>
      <Text style={[styles.amount, getTextColor(item)]}>{item.amount} €</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  view: {
    borderRadius: 25,
    flexDirection: 'row',
    padding: 20,
    borderWidth: 1,
    borderColor: Colors.text,
    marginVertical: 10,
  },
  description: {
    flexGrow: 3,
    fontSize: Sizes.medium,
    fontWeight: Weights.medium,
    color: Colors.text,
  },
  amount: {
    fontSize: Sizes.medium,
    fontWeight: Weights.bold,
    color: Colors.text,
    flexGrow: 1,
    textAlign: 'right',
  },
});
export default ExpenseListItem;
