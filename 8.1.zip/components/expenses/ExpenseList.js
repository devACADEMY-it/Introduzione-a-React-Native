import React from 'react';
import {FlatList} from 'react-native';
import {data} from '../../data/data';
import ExpenseListItem from './ExpenseListItem';

function ExpenseList() {
  return (
    <>
      <FlatList
        style={{marginBottom: 140}}
        data={data}
        renderItem={({item}) => <ExpenseListItem item={item} />}
        keyExtractor={item => item.id}
      />
    </>
  );
}

export default ExpenseList;
