import React from 'react';
import {SafeAreaView, StyleSheet, Text, View} from 'react-native';
import {Colors, Sizes} from '../theme/theme';
import Title from '../components/generics/Title';

function Settings() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.view}>
        <Title text="Settings" />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  view: {
    flex: 1,
    backgroundColor: Colors.white,
    padding: 30,
  },
  text: {
    fontSize: Sizes.large,
    color: Colors.text,
  },
});

export default Settings;
