import React from 'react';
import {SafeAreaView, StyleSheet, Text, View} from 'react-native';
import Title from '../components/generics/Title';
import {Colors} from '../theme/theme';
import Subtitle from '../components/generics/Subtitle';
import ExpenseList from '../components/expenses/ExpenseList';
import Info from "../components/generics/Info";

function Home() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.view}>
        <View style={styles.headerView}>
          <Subtitle text="Il tuo resoconto" />
          <Title text="Bentornato, Adriano" />
          <Info text="Ultimo mese: +800 €"></Info>
        </View>
        <View style={styles.listView}>
          <Subtitle text="Ultime spese"></Subtitle>
          <ExpenseList />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  view: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  headerView: {
    padding: 20,
    height: 150,
    backgroundColor: Colors.primary,
  },
  listView: {
    margin: 30,
  },
});

export default Home;
