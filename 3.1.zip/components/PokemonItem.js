import React from 'react';
import { View, Text, Image } from 'react-native';

function PokemonItem({pokemon = {}}) {
  const {id, name} = pokemon;
  return (
    <View style={{flexDirection: 'row', padding: 10}}>
      <Image
        style={{width: 50, height: 50, marginRight: 20}}
        source={{uri: `https://pokeres.bastionbot.org/images/pokemon/${id}.png`}}
      ></Image>
      <Text style={{fontSize: 20, color: '#000'}}>{name}</Text>
    </View>
  );
}

export default PokemonItem;
