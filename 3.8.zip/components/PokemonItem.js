import React from 'react';
import {View, Text, Image, StyleSheet, TouchableOpacity} from 'react-native';

const API_BASE_URL = 'https://pokeres.bastionbot.org/images/pokemon';

function PokemonItem({pokemon = {}, onPress, theme = 'dark'}) {
  const {id, name, type} = pokemon;

  const getBackgroundColor = () => {
    return theme === 'light' ? '#fff' : '#333';
  };

  const getTextColor = () => {
    return theme === 'light' ? '#333' : '#fff';
  };

  return (
    <TouchableOpacity onPress={() => onPress(pokemon)}>
      <View style={{...styles.view, backgroundColor: getBackgroundColor()}}>
        <Image style={styles.image} source={{uri: `${API_BASE_URL}/${id}.png`}} />
        <View style={styles.textView}>
          <Text style={{...styles.title, color: getTextColor()}}>{name}</Text>
          <Text style={{...styles.subtitle, color: getTextColor()}}>
            Type: {type}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  view: {
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 25,
    marginVertical: 10,
    flexDirection: 'row',
    padding: 10,
  },
  image: {
    width: 50,
    height: 50,
    marginRight: 20,
  },
  textView: {
    flexDirection: 'column',
  },
  title: {
    fontSize: 20,
  },
  subtitle: {
    fontSize: 16,
  },
});

export default PokemonItem;
