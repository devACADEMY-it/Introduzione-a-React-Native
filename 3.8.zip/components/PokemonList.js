import React from 'react';
import PokemonItem from './PokemonItem';
import Title from './Title';
import {SectionList} from 'react-native';

function PokemonList({data, theme}) {
  const onPress = pokemon => {
    console.log('hai cliccato su ', pokemon.name);
  };

  return (
    <SectionList
      sections={data}
      renderItem={({item}) => (
        <PokemonItem pokemon={item} onPress={onPress} theme={theme} />
      )}
      keyExtractor={item => item.id}
      renderSectionHeader={({section: {title}}) => <Title text={title} />}
    />
  );
}

export default PokemonList;
