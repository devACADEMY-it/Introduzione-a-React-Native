import React, {useState} from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  TextInput,
  TouchableOpacity,
  Text,
} from 'react-native';
import Title from './components/Title';

const pokemon = [
  {
    title: 'Prima generazione',
    data: [
      {
        id: 1,
        name: 'Bulbasaur',
        type: 'Erba',
      },
      {
        id: 4,
        name: 'Charmander',
        type: 'Fuoco',
      },
      {
        id: 7,
        name: 'Squirtle',
        type: 'Acqua',
      },
      {
        id: 16,
        name: 'Pidgey',
        type: 'Volante',
      },
      {
        id: 25,
        name: 'Pikachu',
        type: 'Elettro',
      },
      {
        id: 150,
        name: 'Meotwo',
        type: 'Psico',
      },
    ],
  },
  {
    title: 'Seconda generazione',
    data: [
      {
        id: 164,
        name: 'Noctowl',
        type: 'Volante',
      },
      {
        id: 190,
        name: 'Aipom',
        type: 'Normale',
      },
      {
        id: 196,
        name: 'Espeon',
        type: 'Psico',
      },
    ],
  },
  {
    title: 'Terza generazione',
    data: [
      {
        id: 272,
        name: 'Ludicolo',
        type: 'Acqua/Erba',
      },
      {
        id: 279,
        name: 'Pelipper',
        type: 'Acqua/Volante',
      },
      {
        id: 384,
        name: 'Rayquaza',
        type: 'Drago/Volante',
      },
    ],
  },
];

function App() {
  const [color, setColor] = useState('black');

  const onChangeHandler = text => {
    setColor(text);
  };

  return (
    <>
      <SafeAreaView>
        <ScrollView style={styles.scrollView}>
          <View style={styles.body}>
            <View style={styles.sectionContainer}>
              <Title text="Input" />
              <TextInput
                style={{borderWidth: 1, borderColor: '#333', padding: 10}}
                value={color}
                onChangeText={text => onChangeHandler(text)}
              />
              <Title text={`Hai scritto ${color}`} />
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: '#ccc',
  },
  body: {
    paddingTop: 50,
    flexDirection: 'column',
    backgroundColor: '#fff',
  },
  sectionContainer: {
    paddingHorizontal: 24,
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
    color: '#fff',
  },
  button: {
    backgroundColor: '#333',
    padding: 10,
    alignItems: 'center',
    borderRadius: 25,
  },
});

export default App;
