import React, {useContext} from 'react';
import {SafeAreaView, StyleSheet, Text, View} from 'react-native';
import Title from '../components/generics/Title';
import {Colors} from '../theme/theme';
import Subtitle from '../components/generics/Subtitle';
import ExpenseList from '../components/expenses/ExpenseList';
import Info from '../components/generics/Info';
import {MoneyContext} from '../context/MoneyContext';

function Home() {
  const context = useContext(MoneyContext);
  const username = context.username.get;
  const items = context.items.get;

  const getSortedItems = () => {
    return items.sort((a, b) => new Date(b.date) - new Date(a.date));
  };

  const getLastMonthExpenses = () => {
    const currentMonth = new Date().getMonth() + 1;
    return items
      .filter(item => {
        const itemMonth = new Date(item.date).getMonth() + 1;
        if (itemMonth === currentMonth) {
          return item;
        }
      })
      .reduce((prev, cur) => {
        const amount = Number(cur.amount);
        return cur.type === 'Income' ? prev + amount : prev - amount;
      }, 0);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.view}>
        <View style={styles.headerView}>
          <Subtitle text="Il tuo resoconto" />
          <Title text={`Bentornato, ${username}`} />
          <Info text={`Ultimo mese: ${getLastMonthExpenses()} €`} />
        </View>
        <View style={styles.listView}>
          <Subtitle text="Ultime spese" />
          <ExpenseList items={getSortedItems()} />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  view: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  headerView: {
    padding: 20,
    height: 150,
    backgroundColor: Colors.primary,
  },
  listView: {
    margin: 30,
  },
});

export default Home;
