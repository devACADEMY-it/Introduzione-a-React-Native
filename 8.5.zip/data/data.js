export const categories = [
  {
    id: 1,
    name: 'Work',
  },
  {
    id: 2,
    name: 'Food',
  },
  {
    id: 3,
    name: 'Car',
  },
  {
    id: 4,
    name: 'Shopping',
  },
  {
    id: 5,
    name: 'Services',
  },
  {
    id: 6,
    name: 'Home',
  },
];

export const data = [
  {
    id: 1,
    categories: [2, 6],
    date: new Date(),
    desc: 'Spesa settimanale',
    amount: 14,
    type: 'Expense',
  },
  {
    id: 2,
    category: [1],
    date: new Date(),
    desc: 'Stipendio',
    amount: 1240.8,
    type: 'Income',
  },
  {
    id: 3,
    category: [6],
    date: new Date(),
    desc: 'Televisore nuovo',
    amount: 250,
    type: 'Expense',
  },
  {
    id: 4,
    category: [5],
    date: new Date(),
    desc: 'Netflix',
    amount: 11.9,
    type: 'Expense',
  },
  {
    id: 5,
    category: [6],
    date: new Date(),
    desc: 'Computer nuovo',
    amount: 150,
    type: 'Expense',
  },
  {
    id: 6,
    category: [5],
    date: new Date(),
    desc: 'Spotify',
    amount: 9.9,
    type: 'Expense',
  },
];
