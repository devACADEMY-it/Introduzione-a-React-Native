import React from 'react';
import {
  SafeAreaView,
  ScrollView,
  TextInput,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {Colors, Sizes, Weights} from '../theme/theme';
import {Picker} from '@react-native-community/picker';
import DatePicker from 'react-native-date-picker';
import Title from '../components/generics/Title';
import {categories} from '../data/data';

function AddNew() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView>
        <View style={styles.view}>
          <Title text="Add New Entry" />
          <Picker>
            <Picker.Item label="Income" value="Income" />
            <Picker.Item label="Expense" value="Expense" />
          </Picker>
          <Text style={styles.text}>Amount</Text>
          <TextInput style={styles.input} value="40" />
          <Text style={styles.text}>Description</Text>
          <TextInput style={styles.input} value="Spesa settimanale" />
          <Text style={styles.text}>Date</Text>
          <DatePicker date={new Date()} />
          <Picker>
            {categories.map(category => (
              <Picker.Item
                key={category.id}
                label={category.name}
                value={category.id}
              />
            ))}
          </Picker>
          <TouchableOpacity style={styles.button}>
            <Text style={{color: Colors.white, fontSize: Sizes.medium}}>Conferma</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  view: {
    flex: 1,
    backgroundColor: Colors.white,
    padding: 30,
  },
  text: {
    fontSize: Sizes.medium,
    color: Colors.text,
    fontWeight: Weights.light,
  },
  input: {
    marginVertical: 5,
    borderWidth: 1,
    borderColor: Colors.disabled,
    padding: 12,
    fontSize: Sizes.medium,
    color: Colors.text,
  },
  button: {
    backgroundColor: Colors.primary,
    padding: 12,
    alignItems: 'center',
    borderRadius: 25,
  },
});

export default AddNew;
