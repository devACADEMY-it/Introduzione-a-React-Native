import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
} from 'react-native';

function App() {
  return (
    <>
      <SafeAreaView>
        <ScrollView style={styles.scrollView}>
          <View style={styles.body}>
            <View style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>1</Text>
              <Text style={styles.sectionDescription}>Testo</Text>
            </View>
            <View style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>2</Text>
              <Text style={styles.sectionDescription}>Testo</Text>
            </View>
            <View style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>3</Text>
              <Text style={styles.sectionDescription}>Testo</Text>
            </View>
            <View style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>4</Text>
              <Text style={styles.sectionDescription}>Testo</Text>
            </View>
            <View style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>5</Text>
              <Text style={styles.sectionDescription}>Testo</Text>
            </View>
            <View style={styles.sectionContainer}>
              <Text style={styles.sectionTitle}>6</Text>
              <Text style={styles.sectionDescription}>Testo</Text>
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: '#ddd',
  },
  body: {
    flexDirection: 'column',
    backgroundColor: '#fff',
  },
  sectionContainer: {
    height: 200,
    backgroundColor: 'red',
    borderWidth: 1,
    borderColor: 'yellow',
    paddingHorizontal: 24,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: '600',
    color: '#fff',
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
    color: '#fff',
  },
  highlight: {
    fontWeight: '700',
  },
});

export default App;
