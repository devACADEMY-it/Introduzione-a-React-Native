import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import Home from './screens/Home';
import Profile from './screens/Profile';
import {createStackNavigator} from '@react-navigation/stack';
import {createDrawerNavigator} from '@react-navigation/drawer';
import PokemonDetail from './screens/PokemonDetail';
import Icon from 'react-native-vector-icons/FontAwesome';

export const API_BASE_URL = 'https://pokeres.bastionbot.org/images/pokemon';
const TabMenu = createBottomTabNavigator();
const HomeStack = createStackNavigator();
const Drawer = createDrawerNavigator();

function HomeStackScreen() {
  return (
    <HomeStack.Navigator>
      <HomeStack.Screen name="Home" component={Home} />
      <HomeStack.Screen name="PokemonDetail" component={PokemonDetail} />
    </HomeStack.Navigator>
  );
}

function App() {
  return (
    <NavigationContainer>
      <Drawer.Navigator initialRouteName="Home">
        <Drawer.Screen
          name="Home"
          component={HomeStackScreen}
          options={{title: 'Home'}}
        />
        <Drawer.Screen
          name="Profile"
          component={Profile}
          options={{title: 'Profile'}}
        />
      </Drawer.Navigator>
    </NavigationContainer>
  );
}

export default App;
