import React from 'react';
import {View, Text, Image, StyleSheet} from 'react-native';

const API_BASE_URL = 'https://pokeres.bastionbot.org/images/pokemon';

function PokemonItem({pokemon = {}}) {
  const {id, name, type} = pokemon;

  return (
    <View style={styles.view}>
      <Image style={styles.image} source={{uri: `${API_BASE_URL}/${id}.png`}} />
      <View style={styles.textView}>
        <Text style={styles.title}>{name}</Text>
        <Text style={styles.subtitle}>
          Type: {type}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  view: {
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 25,
    marginVertical: 10,
    flexDirection: 'row',
    padding: 10,
  },
  image: {
    width: 50,
    height: 50,
    marginRight: 20,
  },
  textView: {
    flexDirection: 'column',
  },
  title: {
    fontSize: 20,
    color: '#000',
  },
  subtitle: {
    fontSize: 16,
    color: '#000',
  },
});

export default PokemonItem;
