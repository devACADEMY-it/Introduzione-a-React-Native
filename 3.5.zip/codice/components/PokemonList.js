import React from 'react';
import PokemonItem from './PokemonItem';
import Title from './Title';
import {SectionList} from 'react-native';

function PokemonList({data}) {
  return (
    <SectionList
      sections={data}
      renderItem={({item}) => <PokemonItem pokemon={item} />}
      keyExtractor={item => item.id}
      renderSectionHeader={({section: {title}}) => <Title text={title} />}
    />
  );
}

export default PokemonList;
