import React from 'react';
import {SafeAreaView, StyleSheet, Text, View} from 'react-native';
import {Colors, Sizes, Weights} from '../theme/theme';
import Title from '../components/generics/Title';

function EntryDetail({route}) {
  const item = route.params.item;
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.view}>
        <Title text="Detail" />
        <Text style={styles.text}>Description: {item.desc}</Text>
        <Text style={styles.text}>Amount: {item.amount}</Text>
        <Text style={styles.text}>Date: {item.date.toLocaleDateString()}</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  view: {
    flex: 1,
    backgroundColor: Colors.white,
    padding: 30,
  },
  text: {
    fontSize: Sizes.medium,
    color: Colors.text,
    fontWeight: Weights.light,
  },
});

export default EntryDetail;
