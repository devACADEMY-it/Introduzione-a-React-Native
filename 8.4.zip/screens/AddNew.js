import React from 'react';
import {SafeAreaView, StyleSheet, Text, View} from 'react-native';
import {Colors, Sizes} from '../theme/theme';
import Title from '../components/generics/Title';

function AddNew() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.view}>
        <Title text="Add New" />
        <Text>Picker per la scelta della tipologia (Income/Expense)</Text>
        <Text>OK Input per la descrizione</Text>
        <Text>Datepicker per la data</Text>
        <Text>OK Input per l'amount</Text>
        <Text>Picker per la categoria</Text>
        <Text>OK Button per la conferma</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  view: {
    flex: 1,
    backgroundColor: Colors.white,
    padding: 30,
  },
  text: {
    fontSize: Sizes.large,
    color: Colors.text,
  },
});

export default AddNew;
