export const categories = [
  {
    id: 1,
    name: 'Work',
  },
  {
    id: 2,
    name: 'Food',
  },
  {
    id: 3,
    name: 'Car',
  },
  {
    id: 4,
    name: 'Shopping',
  },
  {
    id: 5,
    name: 'Services',
  },
  {
    id: 6,
    name: 'Home',
  },
];
