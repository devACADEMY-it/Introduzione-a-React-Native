import React from 'react';
import {StyleSheet, Text} from 'react-native';
import {Colors, Sizes} from '../../theme/theme';

function Subtitle({text}) {
  return (
    <>
      <Text style={styles.text}>{text}</Text>
    </>
  );
}

const styles = StyleSheet.create({
  text: {
    fontSize: Sizes.small,
    color: Colors.text,
  },
});

export default Subtitle;
