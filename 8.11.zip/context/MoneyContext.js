import React from 'react';

export const MoneyContext = React.createContext({});
