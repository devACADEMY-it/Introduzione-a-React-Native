import React, {useContext} from 'react';
import {SafeAreaView, StyleSheet, Text, TextInput, View} from 'react-native';
import {Colors, Sizes, Weights} from '../theme/theme';
import Title from '../components/generics/Title';
import {MoneyContext} from '../context/MoneyContext';

function Settings() {
  const context = useContext(MoneyContext);
  const username = context.username;
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.view}>
        <Title text="Settings" />
        <View style={{marginTop: 20}}>
          <Text style={styles.text}>Username</Text>
          <TextInput
            style={styles.input}
            value={username.get}
            onChangeText={text => username.set(text)}
          />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  view: {
    flex: 1,
    backgroundColor: Colors.white,
    padding: 30,
  },
  input: {
    marginVertical: 10,
    borderWidth: 1,
    borderColor: Colors.disabled,
    padding: 12,
    fontSize: Sizes.medium,
    color: Colors.text,
  },
  text: {
    fontSize: Sizes.medium,
    color: Colors.text,
    fontWeight: Weights.light,
  },
});

export default Settings;
