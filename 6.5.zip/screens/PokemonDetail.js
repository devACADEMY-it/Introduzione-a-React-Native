import React, {useEffect, useState} from 'react';
import {Image, SafeAreaView, StyleSheet, Text, View} from 'react-native';
import Title from '../components/Title';
import {API_BASE_URL} from '../App';

function PokemonDetail({route, navigation}) {
  const {id, name} = route.params;
  const [pokemon, setPokemon] = useState({});

  useEffect(() => {
    const getPokemon = async () => {
      try {
        const response = await fetch(
          `https://pokeapi.co/api/v2/pokemon/${name}`,
        );
        const json = await response.json();
        setPokemon(json);
      } catch (error) {
        console.log(error);
      }
    };
    getPokemon();
  }, [name]);

  return (
    <SafeAreaView>
      <View style={styles.body}>
        <View style={styles.sectionContainer}>
          <Title text={`Poke: ${name}`} />
          <Image
            style={styles.image}
            source={{uri: `${API_BASE_URL}/${id}.png`}}
          />
          <Text style={styles.text}>Weight: {pokemon.weight}</Text>
          <Text style={styles.text}>Height: {pokemon.height}</Text>
          <Text style={styles.text}>
            Types:{' '}
            {pokemon.types &&
              pokemon.types.map(item => item.type.name).join(' / ')}
          </Text>
          <Title text="Stats" />
          {pokemon.stats &&
            pokemon.stats.map((item, index) => (
              <Text key={index} style={styles.text}>
                {item.stat.name}: {item.base_stat}
              </Text>
            ))}
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: '#fff',
  },
  body: {
    height: '120%',
    paddingTop: 20,
    flexDirection: 'column',
    backgroundColor: '#fff',
  },
  sectionContainer: {
    paddingHorizontal: 20,
    alignItems: 'center',
  },
  image: {
    width: 150,
    height: 150,
  },
  text: {
    fontSize: 18,
    fontWeight: '200',
  },
});

export default PokemonDetail;
