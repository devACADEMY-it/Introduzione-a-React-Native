import React from 'react';
import {SafeAreaView, StyleSheet, View} from 'react-native';
import Title from '../components/generics/Title';
import {Colors} from '../theme/theme';

function Home() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.view}>
        <Title text="Home" />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  view: {
    flex: 1,
    backgroundColor: Colors.white,
    padding: 30,
  },
});

export default Home;
