import React from 'react';
import {SafeAreaView, StyleSheet, View, Button} from 'react-native';
import Title from '../components/Title';
import PokemonList from '../components/PokemonList';

function Home({ navigation }) {
  return (
    <SafeAreaView>
      <View style={styles.body}>
        <View style={styles.sectionContainer}>
          <Button
            title="Go to Profile"
            onPress={() => navigation.navigate('Profile')}
          ></Button>
          <Title text="Pokemon List" />
          <PokemonList />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: '#fff',
  },
  body: {
    paddingTop: 20,
    flexDirection: 'column',
    backgroundColor: '#fff',
  },
  sectionContainer: {
    paddingHorizontal: 20,
  },
});

export default Home;
