import React from 'react';
import {SafeAreaView, StyleSheet, View, Text} from 'react-native';
import {Colors, Sizes} from '../theme/theme';

function Home() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.view}>
        <Text style={styles.text}>Home</Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  view: {
    flex: 1,
    backgroundColor: Colors.white,
    padding: 30,
  },
  text: {
    fontSize: Sizes.large,
    color: Colors.text,
  },
});

export default Home;
