import React from 'react';
import {SafeAreaView, StyleSheet, View} from 'react-native';
import Title from './components/Title';
import {NavigationContainer} from '@react-navigation/native';

function App() {
  return (
    <NavigationContainer>
      <SafeAreaView>
        <View style={styles.body}>
          <View style={styles.sectionContainer}>
            <Title text="Home" />
          </View>
        </View>
      </SafeAreaView>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: '#fff',
  },
  body: {
    paddingTop: 20,
    flexDirection: 'column',
    backgroundColor: '#fff',
  },
  sectionContainer: {
    paddingHorizontal: 20,
  },
});

export default App;
