import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  FlatList,
} from 'react-native';
import DevText from './components/DevText';
import PokemonItem from './components/PokemonItem';

const pokemon = [
  {
    id: 1,
    name: 'Bulbasaur',
    type: 'Erba',
  },
  {
    id: 4,
    name: 'Charmander',
    type: 'Fuoco',
  },
  {
    id: 7,
    name: 'Squirtle',
    type: 'Acqua',
  },
  {
    id: 16,
    name: 'Pidgey',
    type: 'Volante',
  },
  {
    id: 25,
    name: 'Pikachu',
    type: 'Elettro',
  },
];

function App() {
  return (
    <>
      <SafeAreaView>
        <ScrollView style={styles.scrollView}>
          <View style={styles.body}>
            <View style={styles.sectionContainer}>
              <DevText text="My Pokemon" />
              <FlatList
                data={pokemon}
                renderItem={({item}) => <PokemonItem pokemon={item} />}
                keyExtractor={item => item.id}
              />
            </View>
          </View>
        </ScrollView>
      </SafeAreaView>
    </>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: '#ccc',
  },
  body: {
    paddingTop: 50,
    flexDirection: 'column',
    backgroundColor: '#fff',
  },
  sectionContainer: {
    paddingHorizontal: 24,
  },
  sectionDescription: {
    marginTop: 8,
    fontSize: 18,
    fontWeight: '400',
    color: '#fff',
  },
  highlight: {
    fontWeight: '700',
  },
});

export default App;
