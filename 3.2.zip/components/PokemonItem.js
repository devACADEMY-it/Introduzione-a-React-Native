import React from 'react';
import { View, Text, Image } from 'react-native';

function PokemonItem({pokemon = {}}) {
  const {id, name, type} = pokemon;
  return (
    <View style={{flexDirection: 'row', padding: 10}}>
      <Image
        style={{width: 50, height: 50, marginRight: 20}}
        source={{uri: `https://pokeres.bastionbot.org/images/pokemon/${id}.png`}}
      ></Image>
      <View style={{flexDirection: 'column'}}>
        <Text style={{fontSize: 20, color: '#000'}}>{name}</Text>
        <Text style={{fontSize: 16, color: '#000'}}>Type: {type}</Text>
      </View>
    </View>
  );
}

export default PokemonItem;
