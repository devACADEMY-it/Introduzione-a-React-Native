import {Text} from 'react-native';
import React from 'react';

function DevText({text}) {
  return (
    <>
      <Text style={{fontSize: 24, fontWeight: '600', color: '#000'}}>
        {text}
      </Text>
    </>
  );
}

export default DevText;
