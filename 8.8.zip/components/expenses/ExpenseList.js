import React from 'react';
import {FlatList} from 'react-native';
import ExpenseListItem from './ExpenseListItem';
import Title from '../generics/Title';

function ExpenseList({items, goToDetail}) {
  return (
    <>
      <FlatList
        style={{marginBottom: 140}}
        data={items}
        renderItem={({item}) => (
          <ExpenseListItem item={item} goToDetail={goToDetail} />
        )}
        keyExtractor={item => item.id.toString()}
        ListEmptyComponent={<Title text="Nessun elemento trovato" />}
      />
    </>
  );
}

export default ExpenseList;
