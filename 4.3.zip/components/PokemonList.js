import React, {useState, useEffect} from 'react';
import PokemonItem from './PokemonItem';
import {FlatList} from 'react-native';

const pokemon = [
  {
    id: 1,
    name: 'Bulbasaur',
    type: 'Erba',
  },
  {
    id: 4,
    name: 'Charmander',
    type: 'Fuoco',
  },
  {
    id: 7,
    name: 'Squirtle',
    type: 'Acqua',
  },
  {
    id: 16,
    name: 'Pidgey',
    type: 'Volante',
  },
  {
    id: 25,
    name: 'Pikachu',
    type: 'Elettro',
  },
  {
    id: 150,
    name: 'Meotwo',
    type: 'Psico',
  },
  {
    id: 164,
    name: 'Noctowl',
    type: 'Volante',
  },
  {
    id: 190,
    name: 'Aipom',
    type: 'Normale',
  },
  {
    id: 196,
    name: 'Espeon',
    type: 'Psico',
  },
  {
    id: 272,
    name: 'Ludicolo',
    type: 'Acqua/Erba',
  },
  {
    id: 279,
    name: 'Pelipper',
    type: 'Acqua/Volante',
  },
  {
    id: 384,
    name: 'Rayquaza',
    type: 'Drago/Volante',
  },
];

function PokemonList() {
  const [items, setItems] = useState(pokemon);
  const [offset, setOffset] = useState(0);
  const [isLoading, setLoading] = useState(false);

  const getPokemon = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://pokeapi.co/api/v2/pokemon?limit=10&offset=${offset}`,
      );
      const json = await response.json();
      const newItems = json.results.map(item => {
        const splitted = item.url.split('/');
        const len = splitted.length;
        return {
          name: item.name,
          id: splitted[len - 2],
        };
      });

      setItems(newItems);
      setOffset(offset + 10);
    } catch (error) {
      console.log(error);
    }
    setLoading(false);
  };

  useEffect(() => {
    getPokemon();
  }, []);

  const onPress = pokemon => {
    console.log('hai cliccato su ', pokemon.name);
  };

  return (
    <FlatList
      style={{marginBottom: 60}}
      data={items}
      renderItem={({item}) => <PokemonItem pokemon={item} onPress={onPress} />}
      keyExtractor={item => item.id.toString()}
      refreshing={isLoading}
      onRefresh={getPokemon}
    />
  );
}

export default PokemonList;
