import React from 'react';
import {View, Text, Image, StyleSheet, TouchableOpacity} from 'react-native';

const API_BASE_URL = 'https://pokeres.bastionbot.org/images/pokemon';

function PokemonItem({pokemon = {}, onPress}) {
  const {id, name} = pokemon;

  return (
    <TouchableOpacity onPress={() => onPress(pokemon)}>
      <View style={styles.view}>
        <Image
          style={styles.image}
          source={{uri: `${API_BASE_URL}/${id}.png`}}
        />
        <View style={styles.textView}>
          <Text style={styles.title}>{name}</Text>
        </View>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  view: {
    borderWidth: 1,
    borderColor: '#333',
    borderRadius: 25,
    marginVertical: 10,
    flexDirection: 'row',
    padding: 10,
    backgroundColor: '#333',
  },
  image: {
    width: 50,
    height: 50,
    marginRight: 20,
  },
  textView: {
    flexDirection: 'column',
  },
  title: {
    fontSize: 20,
    color: '#fff',
  },
  subtitle: {
    fontSize: 16,
    color: '#fff',
  },
});

export default PokemonItem;
