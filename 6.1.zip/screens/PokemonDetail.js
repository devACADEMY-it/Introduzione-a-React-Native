import React from 'react';
import {Button, SafeAreaView, StyleSheet, View} from 'react-native';
import Title from '../components/Title';

function PokemonDetail({route, navigation}) {
  const {name} = route.params;

  return (
    <SafeAreaView>
      <View style={styles.body}>
        <View style={styles.sectionContainer}>
          <Title text={`Poke ${name}`} />
          <Button
            title="Go back"
            onPress={() => navigation.goBack()}
          ></Button>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: '#fff',
  },
  body: {
    height: '120%',
    paddingTop: 20,
    flexDirection: 'column',
    backgroundColor: '#fff',
  },
  sectionContainer: {
    paddingHorizontal: 20,
  },
});

export default PokemonDetail;
