import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createStackNavigator} from '@react-navigation/stack';
import Home from './screens/Home';
import PokemonDetail from './screens/PokemonDetail';

export const API_BASE_URL = 'https://pokeres.bastionbot.org/images/pokemon';
const Stack = createStackNavigator();

function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: {
            backgroundColor: '#333',
          },
          headerTintColor: '#fff',
          headerTitleStyle: {
            fontWeight: '600',
            fontSize: 20,
          },
        }}>
        <Stack.Screen
          name="Home"
          component={Home}
          options={{title: 'Pokemon List'}}
        />
        <Stack.Screen
          name="PokemonDetail"
          component={PokemonDetail}
          options={{title: 'Poke Detail'}}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default App;
