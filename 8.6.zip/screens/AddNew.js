import React, {useState, useContext} from 'react';
import {
  SafeAreaView,
  ScrollView,
  TextInput,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import {Colors, Sizes, Weights} from '../theme/theme';
import {Picker} from '@react-native-community/picker';
import DatePicker from 'react-native-date-picker';
import Title from '../components/generics/Title';
import {categories} from '../data/data';
import {MoneyContext} from '../context/MoneyContext';

const initialEntry = {
  category: 2,
  type: 'Expense',
  amount: '10',
  desc: '',
  date: new Date(),
};

function AddNew({navigation}) {
  const context = useContext(MoneyContext);
  const [entry, setEntry] = useState(initialEntry);

  const onAddEntry = () => {
    const items = context.items;
    const newId = items.length + 1;
    const newItems = [...items, {id: newId, ...entry}];
    context.setItems(newItems);
    setEntry(initialEntry);
    navigation.navigate('Home');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <ScrollView>
        <View style={styles.view}>
          <Title text="Add New Entry" />
          <View style={{flexDirection: 'row'}}>
            <Picker
              style={{flexGrow: 1, marginHorizontal: 5}}
              selectedValue={entry.type}
              onValueChange={itemValue =>
                setEntry({...entry, type: itemValue})
              }>
              <Picker.Item label="Income" value="Income" />
              <Picker.Item label="Expense" value="Expense" />
            </Picker>
            <Picker
              style={{flexGrow: 1, marginHorizontal: 5}}
              selectedValue={entry.category}
              onValueChange={itemValue =>
                setEntry({...entry, category: itemValue})
              }>
              {categories.map(category => (
                <Picker.Item
                  key={category.id}
                  label={category.name}
                  value={category.id}
                />
              ))}
            </Picker>
          </View>
          <Text style={styles.text}>Amount</Text>
          <TextInput
            style={styles.input}
            keyboardType="numeric"
            value={entry.amount}
            onChangeText={text => setEntry({...entry, amount: text})}
          />
          <Text style={styles.text}>Description</Text>
          <TextInput
            style={styles.input}
            value={entry.desc}
            onChangeText={text => setEntry({...entry, desc: text})}
          />
          <Text style={styles.text}>Date</Text>
          <DatePicker
            mode="date"
            locale="it"
            date={entry.date}
            onDateChange={date => setEntry({...entry, date})}
          />
        </View>
      </ScrollView>
      <TouchableOpacity style={styles.button} onPress={onAddEntry}>
        <Text style={{color: Colors.white, fontSize: Sizes.medium}}>
          Conferma
        </Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  view: {
    flex: 1,
    backgroundColor: Colors.white,
    padding: 30,
  },
  text: {
    fontSize: Sizes.medium,
    color: Colors.text,
    fontWeight: Weights.light,
  },
  input: {
    marginVertical: 10,
    borderWidth: 1,
    borderColor: Colors.disabled,
    padding: 12,
    fontSize: Sizes.medium,
    color: Colors.text,
  },
  button: {
    marginHorizontal: 30,
    marginVertical: 10,
    backgroundColor: Colors.primary,
    padding: 12,
    alignItems: 'center',
    borderRadius: 25,
  },
});

export default AddNew;
