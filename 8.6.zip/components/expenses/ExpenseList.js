import React from 'react';
import {FlatList} from 'react-native';
import ExpenseListItem from './ExpenseListItem';
import Title from "../generics/Title";

function ExpenseList({items}) {
  return (
    <>
      <FlatList
        style={{marginBottom: 140}}
        data={items}
        renderItem={({item}) => <ExpenseListItem item={item} />}
        keyExtractor={item => item.id.toString()}
        ListEmptyComponent={<Title text="Nessun elemento trovato" />}
      />
    </>
  );
}

export default ExpenseList;
