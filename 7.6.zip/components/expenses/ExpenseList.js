import React from 'react';
import {FlatList} from 'react-native';
import {data} from "../../data/data";
import ExpenseListItem from "./ExpenseListItem";

function ExpenseList() {
  return (
    <>
      <FlatList
        data={data}
        renderItem={({item}) => <ExpenseListItem/>}
      />
    </>
  );
}

export default ExpenseList;
