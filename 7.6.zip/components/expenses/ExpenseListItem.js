import React from 'react';
import {Text} from 'react-native';

function ExpenseListItem() {
  return (
    <Text>Ciao</Text>
  );
}

export default ExpenseListItem;
