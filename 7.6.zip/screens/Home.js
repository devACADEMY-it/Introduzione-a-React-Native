import React from 'react';
import {SafeAreaView, StyleSheet, FlatList, View} from 'react-native';
import Title from '../components/generics/Title';
import {Colors} from '../theme/theme';
import Subtitle from '../components/generics/Subtitle';
import ExpenseList from '../components/expenses/ExpenseList';

function Home() {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.view}>
        <Subtitle text="Il tuo resoconto" />
        <Title text="Bentornato, Adriano" />
        <View>
          <ExpenseList />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  view: {
    flex: 1,
    backgroundColor: Colors.white,
    padding: 30,
  },
});

export default Home;
