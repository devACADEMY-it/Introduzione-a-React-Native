export const categories = [
  {
    id: 1,
    name: 'Food',
  },
  {
    id: 2,
    name: 'Clothes',
  },
  {
    id: 3,
    name: 'Bills',
  },
  {
    id: 4,
    name: 'Car',
  },
  {
    id: 5,
    name: 'Shopping',
  },
  {
    id: 6,
    name: 'Services',
  },
  {
    id: 7,
    name: 'House',
  },
  {
    id: 8,
    name: 'Work',
  },
];

export const data = [
  {
    id: 1,
    category: 'Food',
    date: new Date(),
    desc: 'Spesa settimana',
    amount: 14,
    type: 'Expense',
  },
  {
    id: 2,
    category: 'Work',
    date: new Date(),
    desc: 'Stipendio',
    amount: 1240.8,
    type: 'Income',
  },
  {
    id: 3,
    category: 'House',
    date: new Date(),
    desc: 'Televisore nuovo',
    amount: 250,
    type: 'Expense',
  },
  {
    id: 4,
    category: 'Services',
    date: new Date(),
    desc: 'Netflix',
    amount: 11.9,
    type: 'Expense',
  },
];
