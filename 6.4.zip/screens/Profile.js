import React from 'react';
import {SafeAreaView, StyleSheet, View} from 'react-native';
import Title from '../components/Title';

function Profile() {
  return (
    <SafeAreaView>
      <View style={styles.body}>
        <View style={styles.sectionContainer}>
          <Title text="Profile" />
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: '#fff',
  },
  body: {
    paddingTop: 20,
    flexDirection: 'column',
    backgroundColor: '#fff',
  },
  sectionContainer: {
    paddingHorizontal: 20,
  },
});

export default Profile;
