import React, {useState, useEffect} from 'react';
import PokemonItem from './PokemonItem';
import {FlatList} from 'react-native';

function PokemonList({onPress}) {
  const [items, setItems] = useState([]);
  const [offset, setOffset] = useState(0);
  const [isLoading, setLoading] = useState(false);

  const getPokemon = async () => {
    setLoading(true);
    try {
      const response = await fetch(
        `https://pokeapi.co/api/v2/pokemon?limit=10&offset=${offset}`,
      );
      const json = await response.json();
      if (json.results.length > 0) {
        const newItems = json.results.map(item => {
          const splitted = item.url.split('/');
          const len = splitted.length;
          return {
            name: item.name,
            id: splitted[len - 2],
          };
        });
        setItems(items.concat(newItems));
        setOffset(offset + 10);
      }
    } catch (error) {
      console.log(error);
    }
    setLoading(false);
  };

  useEffect(() => {
    getPokemon();
  }, []);

  return (
    <FlatList
      style={{marginBottom: 60}}
      data={items}
      renderItem={({item}) => <PokemonItem pokemon={item} onPress={onPress} />}
      keyExtractor={(item, index) => index.toString()}
      onEndReached={getPokemon}
      onEndReachedThreshold={0}
    />
  );
}

export default PokemonList;
