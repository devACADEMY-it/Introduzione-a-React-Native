import React from 'react';
import {NavigationContainer} from '@react-navigation/native';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import Home from './screens/Home';
import Profile from './screens/Profile';
import {createStackNavigator} from '@react-navigation/stack';
import PokemonDetail from './screens/PokemonDetail';

export const API_BASE_URL = 'https://pokeres.bastionbot.org/images/pokemon';
const TabMenu = createBottomTabNavigator();
const HomeStack = createStackNavigator();

function HomeStackScreen() {
  return (
    <HomeStack.Navigator>
      <HomeStack.Screen name="Home" component={Home} />
      <HomeStack.Screen name="PokemonDetail" component={PokemonDetail} />
    </HomeStack.Navigator>
  );
}

function App() {
  return (
    <NavigationContainer>
      <TabMenu.Navigator
        tabBarOptions={{
          activeTintColor: '#333',
          inactiveTintColor: '#ccc',
          labelStyle: {
            fontSize: 16,
          },
        }}>
        <TabMenu.Screen
          name="HomeTab"
          component={HomeStackScreen}
          options={{title: 'Home'}}
        />
        <TabMenu.Screen
          name="ProfileTab"
          component={Profile}
          options={{title: 'Profile'}}
        />
      </TabMenu.Navigator>
    </NavigationContainer>
  );
}

export default App;
